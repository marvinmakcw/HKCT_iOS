//
//  MainController.swift
//  WarCardGame
//
//  Created by terry on 28/4/2021.
//  Copyright © 2021 Marvin. All rights reserved.
//

import UIKit

class MainController: NSObject {

}
